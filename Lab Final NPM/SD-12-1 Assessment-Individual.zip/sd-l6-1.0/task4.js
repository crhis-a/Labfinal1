// Task 4: delUser(number)

