// Task 3: addUser(first_name, last_name, email)

