// Task 1: getServerURL()

